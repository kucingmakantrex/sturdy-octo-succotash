# HiOS Tilt Animation (LSPosed)

Modul LSPosed untuk efek miring saat buka/tutup aplikasi di HiOS Launcher
(`com.transsion.hilauncher`). Dua jalur:

- **3D snapshot** (`Snapshot3D.java`): jendela ditangkap lalu diputar di overlay dengan
  `rotationX` + `cameraDistance` (trapesium sungguhan). Isi aplikasi diam selama animasi.
- **2D** (`TiltMath.java`): rotate/skew/squash pada matriks jendela. Dipakai otomatis
  kalau snapshot gagal.

## Build di GitHub
1. Buat repo baru, upload semua isi folder ini (termasuk `.github`).
2. Buka tab **Actions** → **Build APK** (jalan otomatis saat push, atau **Run workflow**).
3. Unduh artifact **HiOSTilt-debug** → `app-debug.apk`.

## Pasang
1. Pasang APK, aktifkan di LSPosed dengan scope **com.transsion.hilauncher**.
2. Force stop launcher (atau reboot), lalu coba buka/tutup aplikasi.
3. Log: LSPosed → Logs → Modules, cari `[HiOSTilt]`.

## Pengaturan
Semua di `app/src/main/java/com/hios/tilt/TiltConfig.java`:
- `USE_SNAPSHOT_3D = false` → hanya 2D
- `SNAP_TILT_DEG` negatif → membalik arah 3D; `SNAP_CAMERA_DIST` → kekuatan perspektif (makin kecil makin kuat)
- `SIDE_SIGN`, `ROLL_DEG`, `SKEW_X`, `PITCH_SQUASH` → tilt 2D

## Catatan
- `TiltMath` dan `MainHook` adalah rekonstruksi dari APK sebelumnya (konstanta sama, rumus
  bisa sedikit berbeda). Folder `xposed-stub` hanya stub untuk compile; tidak ikut ke APK.
- Log yang dicari: `overlay 3D aktif` (sukses), `captureLayers gagal` / `build overlay gagal`
  (kembali ke 2D), `surface bukan target aplikasi` (field `mAppTargets`/`leash` tidak cocok).
