plugins {
    id("com.android.application")
}

android {
    namespace = "com.hios.tilt"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hios.tilt"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0-snapshot3d"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // API Xposed hanya dibutuhkan saat compile (disediakan LSPosed saat runtime)
    compileOnly(project(":xposed-stub"))
}
