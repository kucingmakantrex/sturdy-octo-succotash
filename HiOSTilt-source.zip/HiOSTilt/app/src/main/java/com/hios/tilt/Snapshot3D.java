package com.hios.tilt;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 3D snapshot: jendela aplikasi ditangkap (ScreenCapture.captureLayers pada leash),
 * lalu ditampilkan di overlay window dan diputar dengan rotationX + cameraDistance.
 * Leash asli disembunyikan (alpha 0) selama animasi.
 *
 * Pemakaian di MainHook:
 *   1) handleLoadPackage (paket launcher):  Snapshot3D.install(lpparam.classLoader);
 *   2) awal hook SurfaceProperties.setMatrix (beforeHookedMethod), sebelum tilt 2D:
 *        Matrix m = (Matrix) param.args[0];
 *        Object leash = XposedHelpers.getObjectField(param.thisObject, "mSurface");
 *        if (Snapshot3D.onFrame(leash, m)) return;   // overlay 3D yang menangani
 */
public final class Snapshot3D {
    private static final String TAG = "[HiOSTilt] ";

    // ---- pengaturan ----
    public static boolean ENABLED = true;
    public static float TILT_DEG = 14f;      // maks. kemiringan sumbu X (ubah ke negatif jika arahnya terbalik)
    public static float SIDE_DEG = 4f;       // kemiringan sumbu Y mengikuti posisi ikon
    public static float CAMERA_DIST = 9000f; // makin besar = perspektif makin halus (dikali density)
    public static float FULL_RANGE = 0.7f;   // skala jendela yang dianggap "tilt penuh"
    private static final long END_DELAY_MS = 150;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static Class<?> sTxClass;
    private static boolean sInstalled;

    private static volatile Object sLeash;
    private static volatile Object sSkip;
    private static volatile boolean sReady;
    private static volatile float sSx = 1f, sSy = 1f, sTx, sTy, sSide;

    private static WindowManager sWm;
    private static FrameLayout sRoot, sHolder;
    private static ImageView sImg;
    private static volatile int sW, sH;

    private Snapshot3D() {}

    public static synchronized void install(ClassLoader cl) {
        if (sInstalled) return;
        try {
            sTxClass = XposedHelpers.findClass("android.view.SurfaceControl$Transaction", cl);
            // paksa leash asli tetap transparan selama overlay tampil
            XposedBridge.hookAllMethods(sTxClass, "setAlpha", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (sReady && p.args.length == 2 && same(p.args[0], sLeash)) {
                        p.args[1] = 0f;
                    }
                }
            });
            XposedBridge.hookAllMethods(sTxClass, "setMatrix", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (sReady && p.args.length > 0 && same(p.args[0], sLeash)) {
                        try {
                            XposedHelpers.callMethod(p.thisObject, "setAlpha", p.args[0], 0f);
                        } catch (Throwable ignored) { }
                    }
                }
            });
            sInstalled = true;
        } catch (Throwable t) {
            ENABLED = false;
            XposedBridge.log(TAG + "Snapshot3D.install gagal: " + t);
        }
    }

    /** @return true jika overlay 3D sedang menangani frame ini (lewati tilt 2D). */
    public static boolean onFrame(Object leash, Matrix m) {
        if (!ENABLED || !sInstalled || leash == null || m == null) return false;
        if (sSkip != null && same(sSkip, leash)) return false;

        if (sLeash == null) {
            if (!begin(leash)) {
                sSkip = leash;
                return false;
            }
        } else if (!same(sLeash, leash)) {
            return false;
        }

        float[] v = new float[9];
        m.getValues(v);
        sSx = v[Matrix.MSCALE_X];
        sSy = v[Matrix.MSCALE_Y];
        sTx = v[Matrix.MTRANS_X];
        sTy = v[Matrix.MTRANS_Y];
        int w = sW;
        if (w > 0) {
            float cx = sTx + w * sSx / 2f;
            float f = (cx - w / 2f) / (w / 2f);
            sSide = Math.max(-1f, Math.min(1f, f));
        }
        MAIN.post(UPDATE);
        MAIN.removeCallbacks(END);
        MAIN.postDelayed(END, END_DELAY_MS);
        return sReady;
    }

    // ---------------------------------------------------------------

    private static boolean begin(Object leash) {
        Bitmap bmp = null;
        try {
            Class<?> sc = XposedHelpers.findClass("android.window.ScreenCapture", null);
            Class<?> scl = XposedHelpers.findClass("android.view.SurfaceControl", null);
            Object buf = XposedHelpers.callStaticMethod(sc, "captureLayers",
                    new Class<?>[]{scl, Rect.class, float.class}, leash, null, 1f);
            if (buf != null) bmp = (Bitmap) XposedHelpers.callMethod(buf, "asBitmap");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "captureLayers gagal: " + t);
        }
        if (bmp == null) {
            XposedBridge.log(TAG + "snapshot kosong, pakai 2D");
            return false;
        }
        sLeash = leash;
        final Bitmap b = bmp;
        MAIN.post(new Runnable() { @Override public void run() { build(b); } });
        return true;
    }

    private static void build(Bitmap b) {
        try {
            Context ctx = (Context) XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
            sWm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            int w = b.getWidth(), h = b.getHeight();

            sRoot = new FrameLayout(ctx);
            sRoot.setClipChildren(false);
            sHolder = new FrameLayout(ctx);
            sHolder.setClipChildren(false);
            sHolder.setPivotX(0f);
            sHolder.setPivotY(0f);

            sImg = new ImageView(ctx);
            sImg.setScaleType(ImageView.ScaleType.FIT_XY);
            sImg.setImageBitmap(b);
            sImg.setCameraDistance(CAMERA_DIST * ctx.getResources().getDisplayMetrics().density);
            sImg.setPivotX(w / 2f);
            sImg.setPivotY(h / 2f);

            sHolder.addView(sImg, new FrameLayout.LayoutParams(w, h));
            sRoot.addView(sHolder, new FrameLayout.LayoutParams(w, h));

            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                    2038 /* TYPE_APPLICATION_OVERLAY */, flags, PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.layoutInDisplayCutoutMode = 3; // ALWAYS
            lp.setFitInsetsTypes(0);
            lp.setTitle("HiOSTilt3D");
            sWm.addView(sRoot, lp);

            sW = w;
            sH = h;
            applyState();
            sReady = true;
            XposedBridge.log(TAG + "overlay 3D aktif " + w + "x" + h);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "build overlay gagal: " + t);
            sSkip = sLeash;
            endNow();
        }
    }

    private static void applyState() {
        FrameLayout holder = sHolder;
        ImageView img = sImg;
        if (holder == null || img == null) return;
        holder.setTranslationX(sTx);
        holder.setTranslationY(sTy);
        holder.setScaleX(sSx);
        holder.setScaleY(sSy);
        float k = Math.max(0f, Math.min(1f, (1f - Math.max(sSx, sSy)) / FULL_RANGE));
        img.setRotationX(TILT_DEG * k);
        img.setRotationY(-sSide * SIDE_DEG * k);
    }

    private static final Runnable UPDATE = new Runnable() {
        @Override public void run() { applyState(); }
    };

    private static final Runnable END = new Runnable() {
        @Override public void run() { endNow(); }
    };

    private static void endNow() {
        Object leash = sLeash;
        boolean was = sReady;
        sReady = false;
        if (was && leash != null) {
            try {
                Object tx = XposedHelpers.newInstance(sTxClass);
                XposedHelpers.callMethod(tx, "setAlpha", leash, 1f);
                XposedHelpers.callMethod(tx, "apply");
            } catch (Throwable ignored) { }
        }
        try {
            if (sWm != null && sRoot != null) sWm.removeViewImmediate(sRoot);
        } catch (Throwable ignored) { }
        sRoot = null;
        sHolder = null;
        sImg = null;
        sLeash = null;
        sSkip = null;
        sW = 0;
        sH = 0;
    }

    private static boolean same(Object a, Object b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        try {
            return (Boolean) XposedHelpers.callMethod(a, "isSameSurface", b);
        } catch (Throwable t) {
            return false;
        }
    }
}
