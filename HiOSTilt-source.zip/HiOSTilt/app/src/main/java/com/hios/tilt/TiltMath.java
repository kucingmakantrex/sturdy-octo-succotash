package com.hios.tilt;

import android.graphics.Matrix;

/** Tilt 2D pada matriks jendela (rekonstruksi dari konstanta APK sebelumnya). */
final class TiltMath {
    private TiltMath() {}

    static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** @return matriks baru yang sudah dimiringkan, atau null jika tidak perlu. */
    static Matrix tilt(Matrix src, float screenW, float screenH, boolean opening) {
        float[] v = new float[9];
        src.getValues(v);
        float scale = (float) Math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]);
        if (scale <= 0f) return null;

        float span = 1f - TiltConfig.FULL_TILT_SCALE;
        float t = clamp((1f - scale) / (span <= 0f ? 0.01f : span), 0f, 1f);
        t = (float) Math.pow(t, TiltConfig.EASE_POWER);
        if (t < 0.001f) return null;

        float[] c = {screenW / 2f, screenH / 2f};
        src.mapPoints(c);
        float side = clamp((c[0] - screenW / 2f) / (screenW / 2f), -1f, 1f);
        float mag = Math.max(Math.abs(side), TiltConfig.MIN_SIDE);
        side = (side >= 0f ? 1f : -1f) * mag * TiltConfig.SIDE_SIGN;
        if (!opening && TiltConfig.CLOSE_FLIP) side = -side;

        Matrix out = new Matrix(src);
        out.postRotate(TiltConfig.ROLL_DEG * side * t, c[0], c[1]);
        out.postSkew(TiltConfig.SKEW_X * side * t, 0f, c[0], c[1]);
        out.postScale(1f, 1f - TiltConfig.PITCH_SQUASH * t, c[0], c[1]);
        return out;
    }
}
