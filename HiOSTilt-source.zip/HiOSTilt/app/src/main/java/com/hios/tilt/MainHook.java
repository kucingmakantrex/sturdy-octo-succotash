package com.hios.tilt;

import android.content.res.Resources;
import android.graphics.Matrix;
import android.util.DisplayMetrics;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "[HiOSTilt] ";
    private static final String LAUNCHER_PKG = "com.transsion.hilauncher";
    private static final String CLS_RUNNER = "com.android.launcher3.animation.TrWindowAnimRunner";
    private static final String CLS_PROPS = "com.android.quickstep.util.SurfaceTransaction$SurfaceProperties";
    private static final String CLS_TX = "android.view.SurfaceControl$Transaction";

    private static final int MODE_OPENING = 0;
    private static final int MODE_CLOSING = 1;

    private static volatile Object sRunner;
    private static final ThreadLocal<Boolean> sApplied = new ThreadLocal<>();
    private static int sDebugUpdate, sDebugApplied, sDebugMiss;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!LAUNCHER_PKG.equals(lpparam.packageName) || !TiltConfig.ENABLED) return;
        ClassLoader cl = lpparam.classLoader;
        log("memuat modul di " + lpparam.processName);

        if (TiltConfig.USE_SNAPSHOT_3D) {
            Snapshot3D.TILT_DEG = TiltConfig.SNAP_TILT_DEG;
            Snapshot3D.SIDE_DEG = TiltConfig.SNAP_SIDE_DEG;
            Snapshot3D.CAMERA_DIST = TiltConfig.SNAP_CAMERA_DIST;
            Snapshot3D.install(cl);
        }
        hookRunner(cl);
        hookPropsSetMatrix(cl);
        hookTransactionSetMatrix(cl);
    }

    // ---- hook ----

    private void hookRunner(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClassIfExists(CLS_RUNNER, cl);
            if (c == null) { log("class tidak ditemukan: " + CLS_RUNNER); return; }
            XposedBridge.hookAllMethods(c, "onUpdate", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    sRunner = p.thisObject;
                    if (TiltConfig.DEBUG_LOG && sDebugUpdate++ < 5) {
                        Object t = safeField(p.thisObject, "mAppTargets");
                        log("runner.onUpdate: targets=" + (t instanceof Object[] ? ((Object[]) t).length : t));
                    }
                }
            });
            log("hook runner=" + c.getName());
        } catch (Throwable t) {
            log("hookRunner gagal: " + t);
        }
    }

    private void hookPropsSetMatrix(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClassIfExists(CLS_PROPS, cl);
            if (c == null) { log("class tidak ditemukan: " + CLS_PROPS); return; }
            XposedBridge.hookAllMethods(c, "setMatrix", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args.length < 1 || !(p.args[0] instanceof Matrix)) return;
                        Object surface = XposedHelpers.getObjectField(p.thisObject, "mSurface");
                        if (process(p.args, 0, surface, "props.setMatrix")) sApplied.set(Boolean.TRUE);
                    } catch (Throwable t) {
                        debugError(t);
                    }
                }
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    sApplied.remove();
                }
            });
            if (TiltConfig.USE_SNAPSHOT_3D) {
                XposedBridge.hookAllMethods(c, "setWindowCrop", new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        try {
                            if (p.args.length == 1 && p.args[0] instanceof android.graphics.Rect) {
                                Snapshot3D.onCrop(XposedHelpers.getObjectField(p.thisObject, "mSurface"),
                                        new android.graphics.Rect((android.graphics.Rect) p.args[0]));
                            }
                        } catch (Throwable t) { debugError(t); }
                    }
                });
                XposedBridge.hookAllMethods(c, "setCornerRadius", new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        try {
                            if (p.args.length == 1 && p.args[0] instanceof Float) {
                                Snapshot3D.onCorner(XposedHelpers.getObjectField(p.thisObject, "mSurface"),
                                        (Float) p.args[0]);
                            }
                        } catch (Throwable t) { debugError(t); }
                    }
                });
            }
        } catch (Throwable t) {
            log("hookPropsSetMatrix gagal: " + t);
        }
    }

    private void hookTransactionSetMatrix(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClassIfExists(CLS_TX, cl);
            if (c == null) { log("class tidak ditemukan: " + CLS_TX); return; }
            XposedBridge.hookAllMethods(c, "setMatrix", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (Boolean.TRUE.equals(sApplied.get())) return;      // sudah ditangani di props
                        if (p.args.length != 3 || !(p.args[1] instanceof Matrix)) return;
                        process(p.args, 1, p.args[0], "tx.setMatrix");
                    } catch (Throwable t) {
                        debugError(t);
                    }
                }
            });
        } catch (Throwable t) {
            log("hookTransactionSetMatrix gagal: " + t);
        }
    }

    // ---- inti ----

    /** @return true jika frame ini ditangani (2D diterapkan atau overlay 3D aktif). */
    private static boolean process(Object[] args, int idx, Object surface, String src) {
        Integer mode = appTargetMode(surface);
        if (mode == null) {
            if (TiltConfig.DEBUG_LOG && sDebugMiss++ < 3) log("surface bukan target aplikasi (dilewati)");
            return false;
        }
        boolean opening = mode == MODE_OPENING;
        if (opening && !TiltConfig.APPLY_ON_OPEN) return false;
        if (mode == MODE_CLOSING && !TiltConfig.APPLY_ON_CLOSE) return false;
        if (!TiltConfig.APPLY_ON_GESTURE && safeField(sRunner, "mGestureState") != null) return false;

        Matrix orig = (Matrix) args[idx];

        if (TiltConfig.USE_SNAPSHOT_3D && Snapshot3D.onFrame(surface, orig)) return true;

        DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
        Matrix tilted = TiltMath.tilt(orig, dm.widthPixels, dm.heightPixels, opening);
        if (tilted == null) return false;
        args[idx] = tilted;
        if (TiltConfig.DEBUG_LOG && sDebugApplied++ < 5) log("tilt diterapkan, opening=" + opening + ", " + src);
        return true;
    }

    /** @return mode RemoteAnimationTarget jika surface adalah leash aplikasi, selain itu null. */
    private static Integer appTargetMode(Object surface) {
        Object runner = sRunner;
        if (runner == null || surface == null) return null;
        Object targets = safeField(runner, "mAppTargets");
        if (!(targets instanceof Object[])) return null;
        for (Object t : (Object[]) targets) {
            if (t == null) continue;
            try {
                Object leash = XposedHelpers.getObjectField(t, "leash");
                if (same(leash, surface)) return XposedHelpers.getIntField(t, "mode");
            } catch (Throwable ignored) { }
        }
        return null;
    }

    private static boolean same(Object a, Object b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        try {
            return (Boolean) XposedHelpers.callMethod(a, "isSameSurface", b);
        } catch (Throwable t) {
            return false;
        }
    }

    private static Object safeField(Object o, String name) {
        if (o == null) return null;
        try { return XposedHelpers.getObjectField(o, name); } catch (Throwable t) { return null; }
    }

    private static void debugError(Throwable t) {
        if (TiltConfig.DEBUG_LOG) log("error: " + t);
    }

    private static void log(String m) {
        XposedBridge.log(TAG + m);
    }
}
