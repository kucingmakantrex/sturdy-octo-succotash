package com.hios.tilt;

/** Semua pengaturan modul. Ubah nilainya lalu build ulang. */
final class TiltConfig {
    private TiltConfig() {}

    static final boolean ENABLED = true;
    static final boolean DEBUG_LOG = true;

    static final boolean APPLY_ON_OPEN = true;
    static final boolean APPLY_ON_CLOSE = true;
    static final boolean APPLY_ON_GESTURE = true;   // false = lewati animasi yang digerakkan gesture

    // ---- tilt 2D (nilai sama dengan APK sebelumnya) ----
    static final float FULL_TILT_SCALE = 0.85f;     // skala jendela saat tilt penuh
    static final float EASE_POWER = 1.0f;
    static final float MIN_SIDE = 0.35f;            // minimum pengaruh posisi kiri/kanan ikon
    static final float SIDE_SIGN = 1.0f;            // -1 untuk membalik arah
    static final boolean CLOSE_FLIP = false;
    static final float ROLL_DEG = 5.0f;
    static final float SKEW_X = 0.08f;
    static final float PITCH_SQUASH = 0.04f;

    // ---- 3D snapshot (jalur baru) ----
    static final boolean USE_SNAPSHOT_3D = true;    // false = hanya 2D
    static final float SNAP_TILT_DEG = 14f;         // negatif jika arah terbalik
    static final float SNAP_SIDE_DEG = 4f;
    static final float SNAP_CAMERA_DIST = 9000f;    // makin besar = perspektif makin halus
}
