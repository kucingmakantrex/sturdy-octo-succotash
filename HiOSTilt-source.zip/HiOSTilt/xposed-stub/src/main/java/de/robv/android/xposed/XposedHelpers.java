package de.robv.android.xposed;

public final class XposedHelpers {
    private XposedHelpers() {}
    public static Class<?> findClass(String className, ClassLoader classLoader) { return null; }
    public static Class<?> findClassIfExists(String className, ClassLoader classLoader) { return null; }
    public static Object getObjectField(Object obj, String fieldName) { return null; }
    public static int getIntField(Object obj, String fieldName) { return 0; }
    public static Object callMethod(Object obj, String methodName, Object... args) { return null; }
    public static Object callMethod(Object obj, String methodName, Class<?>[] parameterTypes, Object... args) { return null; }
    public static Object callStaticMethod(Class<?> clazz, String methodName, Object... args) { return null; }
    public static Object callStaticMethod(Class<?> clazz, String methodName, Class<?>[] parameterTypes, Object... args) { return null; }
    public static Object newInstance(Class<?> clazz, Object... args) { return null; }
}
