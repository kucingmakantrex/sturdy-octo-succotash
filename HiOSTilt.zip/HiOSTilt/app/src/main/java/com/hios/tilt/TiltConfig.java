package com.hios.tilt;

/**
 * Semua pengaturan efek ada di file ini. Ubah nilainya lalu build ulang modul,
 * kemudian restart HiOS Launcher (atau reboot).
 */
public final class TiltConfig {
    private TiltConfig() {}

    /** Matikan semua efek tanpa menghapus modul. */
    public static final boolean ENABLED = true;

    /** Efek saat membuka / menutup aplikasi. */
    public static final boolean APPLY_ON_OPEN = true;
    public static final boolean APPLY_ON_CLOSE = true;

    /** true = efek juga dipakai saat gestur geser ke atas untuk pulang ke home. */
    public static final boolean APPLY_ON_GESTURE = false;

    /**
     * Skala jendela (0..1) saat efek mencapai kekuatan penuh.
     * Jendela seukuran ikon sekitar 0.15-0.25. Saat skala mendekati 1 (layar penuh), efek hilang.
     */
    public static final float FULL_TILT_SCALE = 0.40f;

    /** 1 = linear. Lebih besar dari 1 = efek makin cepat hilang menjelang layar penuh. */
    public static final float EASE_POWER = 1.4f;

    /** Rotasi maksimum dalam derajat. */
    public static final float ROLL_DEG = 5f;

    /** Shear horizontal maksimum (0.1 = sekitar 6 derajat). Searah dengan rotasi. */
    public static final float SKEW_X = 0.08f;

    /** Pemendekan tinggi jendela (efek bersandar ke belakang). 0 = mati. */
    public static final float PITCH_SQUASH = 0.04f;

    /**
     * Arah miring ditentukan posisi ikon terhadap tengah layar (kiri/kanan).
     * Ikon yang tepat di tengah tetap miring sebesar nilai ini (0..1).
     */
    public static final float MIN_SIDE = 0.35f;

    /** Ubah ke -1f untuk membalik arah miring. */
    public static final float SIDE_SIGN = 1f;

    /** true = arah miring saat menutup dibalik dibanding saat membuka. */
    public static final boolean CLOSE_FLIP = false;

    /** Tulis log ke LSPosed (cari tag [HiOSTilt]). */
    public static final boolean DEBUG_LOG = true;
}
