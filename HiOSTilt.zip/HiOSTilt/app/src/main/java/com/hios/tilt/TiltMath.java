package com.hios.tilt;

import android.content.res.Resources;
import android.graphics.Matrix;
import android.util.DisplayMetrics;

final class TiltMath {
    private TiltMath() {}

    /**
     * Mengembalikan salinan matriks dengan efek miring, atau null kalau tidak perlu diubah.
     * Matriks surface Android hanya affine, jadi hasilnya berupa rotasi + shear + pemendekan
     * (bukan trapesium perspektif).
     */
    static Matrix tilt(Matrix src, boolean opening) {
        float[] v = new float[9];
        src.getValues(v);
        float scale = (float) Math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]);
        if (scale >= 0.999f || scale <= 0.01f) return null;

        float t = (1f - scale) / (1f - TiltConfig.FULL_TILT_SCALE);
        t = clamp(t, 0f, 1f);
        t = (float) Math.pow(t, TiltConfig.EASE_POWER);
        if (t <= 0.001f) return null;

        DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
        float sw = dm.widthPixels;
        float sh = dm.heightPixels;

        // Pusat jendela (layar penuh) setelah transformasi launcher.
        float[] c = {sw / 2f, sh / 2f};
        src.mapPoints(c);

        float side = clamp((c[0] - sw / 2f) / (sw / 2f), -1f, 1f);
        float dir = side >= 0f
                ? Math.max(side, TiltConfig.MIN_SIDE)
                : Math.min(side, -TiltConfig.MIN_SIDE);
        dir *= TiltConfig.SIDE_SIGN;
        if (!opening && TiltConfig.CLOSE_FLIP) dir = -dir;

        Matrix out = new Matrix(src);
        out.postRotate(TiltConfig.ROLL_DEG * t * dir, c[0], c[1]);
        // Tanda minus supaya shear searah dengan rotasi (atas dan bawah condong ke sisi yang sama).
        out.postSkew(-TiltConfig.SKEW_X * t * dir, 0f, c[0], c[1]);
        if (TiltConfig.PITCH_SQUASH > 0f) {
            out.postScale(1f, 1f - TiltConfig.PITCH_SQUASH * t, c[0], c[1]);
        }
        return out;
    }

    private static float clamp(float x, float lo, float hi) {
        return x < lo ? lo : (x > hi ? hi : x);
    }
}
