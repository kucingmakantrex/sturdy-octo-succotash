package com.hios.tilt;

import android.graphics.Matrix;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "[HiOSTilt] ";
    private static final String LAUNCHER_PKG = "com.transsion.hilauncher";

    // Kelas yang benar-benar menggerakkan jendela aplikasi (ada di APK HiOS Launcher 15).
    private static final String CLS_RUNNER = "com.android.launcher3.animation.TrWindowAnimRunner";
    private static final String CLS_PROPS =
            "com.android.quickstep.util.SurfaceTransaction$SurfaceProperties";
    private static final String CLS_TX = "android.view.SurfaceControl$Transaction";

    /** Runner yang sedang menjalankan onUpdate() di thread ini. */
    private static final ThreadLocal<Object> sRunner = new ThreadLocal<Object>();
    /** Penanda matriks sudah dimiringkan di hook level atas (cegah dobel). */
    private static final ThreadLocal<Boolean> sApplied = new ThreadLocal<Boolean>();

    private static int sDebugUpdate = 0;
    private static int sDebugApplied = 0;
    private static int sDebugMiss = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!TiltConfig.ENABLED) return;
        if (!LAUNCHER_PKG.equals(lp.packageName) || !LAUNCHER_PKG.equals(lp.processName)) return;

        ClassLoader cl = lp.classLoader;
        boolean a = hookRunner(cl);
        boolean b = hookPropsSetMatrix(cl);
        boolean c = hookTransactionSetMatrix(cl);
        log("hook runner=" + a + ", props.setMatrix=" + b + ", tx.setMatrix=" + c);
    }

    /** Menandai kapan TrWindowAnimRunner sedang mengirim matriks ke SurfaceControl. */
    private boolean hookRunner(ClassLoader cl) {
        try {
            Class<?> runner = XposedHelpers.findClassIfExists(CLS_RUNNER, cl);
            if (runner == null) {
                log("class tidak ditemukan: " + CLS_RUNNER);
                return false;
            }
            XposedBridge.hookAllMethods(runner, "onUpdate", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    sRunner.set(p.thisObject);
                    if (TiltConfig.DEBUG_LOG && sDebugUpdate < 4) {
                        sDebugUpdate++;
                        try {
                            Object[] t = (Object[]) XposedHelpers.getObjectField(
                                    p.thisObject, "mAppTargets");
                            Object g = XposedHelpers.getObjectField(p.thisObject, "mGestureState");
                            log("runner.onUpdate: targets=" + (t == null ? -1 : t.length)
                                    + ", gesture=" + (g != null));
                        } catch (Throwable e) {
                            log("runner.onUpdate: " + e);
                        }
                    }
                }

                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    sRunner.remove();
                }
            });
            return true;
        } catch (Throwable t) {
            log("hookRunner gagal: " + t);
            return false;
        }
    }

    /** Level 1: SurfaceTransaction.SurfaceProperties.setMatrix(Matrix). */
    private boolean hookPropsSetMatrix(ClassLoader cl) {
        try {
            Class<?> props = XposedHelpers.findClassIfExists(CLS_PROPS, cl);
            if (props == null) {
                log("class tidak ditemukan: " + CLS_PROPS);
                return false;
            }
            XposedHelpers.findAndHookMethod(props, "setMatrix", Matrix.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (sRunner.get() == null) return;
                            try {
                                Object surface =
                                        XposedHelpers.getObjectField(p.thisObject, "mSurface");
                                Matrix out = process((Matrix) p.args[0], surface);
                                if (out != null) {
                                    p.args[0] = out;
                                    sApplied.set(Boolean.TRUE);
                                }
                            } catch (Throwable t) {
                                debugError(t);
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            sApplied.remove();
                        }
                    });
            return true;
        } catch (Throwable t) {
            log("hookPropsSetMatrix gagal: " + t);
            return false;
        }
    }

    /**
     * Level 2: SurfaceControl.Transaction.setMatrix(sc, Matrix, float[]).
     * Cadangan kalau level 1 ter-inline oleh ART dan hook-nya terlewat.
     */
    private boolean hookTransactionSetMatrix(ClassLoader cl) {
        try {
            Class<?> tx = XposedHelpers.findClassIfExists(CLS_TX, cl);
            if (tx == null) {
                log("class tidak ditemukan: " + CLS_TX);
                return false;
            }
            XposedBridge.hookAllMethods(tx, "setMatrix", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (sRunner.get() == null) return;
                    if (sApplied.get() != null) return;
                    if (p.args == null || p.args.length != 3 || !(p.args[1] instanceof Matrix)) {
                        return;
                    }
                    try {
                        Matrix out = process((Matrix) p.args[1], p.args[0]);
                        if (out != null) p.args[1] = out;
                    } catch (Throwable t) {
                        debugError(t);
                    }
                }
            });
            return true;
        } catch (Throwable t) {
            log("hookTransactionSetMatrix gagal: " + t);
            return false;
        }
    }

    /** Mengembalikan matriks yang sudah dimiringkan, atau null kalau tidak perlu. */
    private static Matrix process(Matrix src, Object surface) {
        if (src == null || surface == null) return null;
        Object runner = sRunner.get();
        if (runner == null) return null;

        if (!TiltConfig.APPLY_ON_GESTURE
                && XposedHelpers.getObjectField(runner, "mGestureState") != null) {
            return null;
        }

        Object[] targets = (Object[]) XposedHelpers.getObjectField(runner, "mAppTargets");
        if (targets == null) return null;

        int mode = -1;
        for (Object t : targets) {
            if (t == null) continue;
            if (XposedHelpers.getObjectField(t, "leash") == surface) {
                mode = XposedHelpers.getIntField(t, "mode");
                break;
            }
        }
        if (mode == -1) {
            if (TiltConfig.DEBUG_LOG && sDebugMiss < 3) {
                sDebugMiss++;
                log("surface bukan target aplikasi (dilewati)");
            }
            return null;
        }

        boolean opening = mode != 1; // RemoteAnimationTarget.MODE_CLOSING = 1
        if (opening && !TiltConfig.APPLY_ON_OPEN) return null;
        if (!opening && !TiltConfig.APPLY_ON_CLOSE) return null;

        Matrix out = TiltMath.tilt(src, opening);
        if (out != null && TiltConfig.DEBUG_LOG && sDebugApplied < 5) {
            sDebugApplied++;
            log("tilt diterapkan, opening=" + opening);
        }
        return out;
    }

    private static void debugError(Throwable t) {
        // Jangan pernah membuat launcher crash karena efek.
        if (TiltConfig.DEBUG_LOG && sDebugMiss < 6) {
            sDebugMiss++;
            log("error: " + t);
        }
    }

    private static void log(String msg) {
        XposedBridge.log(TAG + msg);
    }
}
