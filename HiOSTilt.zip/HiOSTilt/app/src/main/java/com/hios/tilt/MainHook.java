package com.hios.tilt;

import android.graphics.Matrix;
import android.os.SystemClock;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "[HiOSTilt] ";
    private static final String LAUNCHER_PKG = "com.transsion.hilauncher";

    private static final String CLS_MANAGER =
            "com.android.launcher3.TrQuickstepTransitionManager";
    private static final String CLS_LAUNCH_RUNNER = CLS_MANAGER + "$TrAppLaunchAnimRunner";
    private static final String CLS_PROPS =
            "com.android.quickstep.util.SurfaceTransaction$SurfaceProperties";

    /** leash jendela aplikasi -> {1 = membuka / 0 = menutup, batas waktu uptimeMillis} */
    private static final Map<Object, long[]> sLeashes =
            Collections.synchronizedMap(new WeakHashMap<Object, long[]>());
    private static volatile long sAnyActiveUntil = 0L;
    private static int sDebugFrames = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!TiltConfig.ENABLED) return;
        if (!LAUNCHER_PKG.equals(lp.packageName) || !LAUNCHER_PKG.equals(lp.processName)) return;

        ClassLoader cl = lp.classLoader;
        boolean a = hookTargets(cl);
        boolean b = hookSetMatrix(cl);
        log("hook targets=" + a + ", setMatrix=" + b);
    }

    /** Mencatat leash jendela aplikasi yang sedang dianimasikan dari/ke ikon. */
    private boolean hookTargets(ClassLoader cl) {
        boolean any = false;
        try {
            Class<?> runner = XposedHelpers.findClassIfExists(CLS_LAUNCH_RUNNER, cl);
            if (runner != null) {
                XposedBridge.hookAllMethods(runner, "onAnimationStart", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        try {
                            if (XposedHelpers.getBooleanField(p.thisObject, "launchFromRecent")) {
                                return;
                            }
                        } catch (Throwable ignored) {
                        }
                        if (p.args != null && p.args.length > 1) record(p.args[1], true);
                    }
                });
                any = true;
            } else {
                log("class tidak ditemukan: " + CLS_LAUNCH_RUNNER);
            }

            Class<?> mgr = XposedHelpers.findClassIfExists(CLS_MANAGER, cl);
            if (mgr != null) {
                XposedBridge.hookAllMethods(mgr, "trComposeIconLaunchAnimator",
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam p) {
                                // (AnimatorSet, View, RemoteAnimationTarget[], boolean)
                                if (p.args != null && p.args.length > 2) record(p.args[2], true);
                            }
                        });
                XposedBridge.hookAllMethods(mgr, "getClosingWindowAnimators",
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam p) {
                                // (RemoteAnimationTarget[], View, float)
                                if (p.args != null && p.args.length > 0) record(p.args[0], false);
                            }
                        });
                any = true;
            } else {
                log("class tidak ditemukan: " + CLS_MANAGER);
            }
        } catch (Throwable t) {
            log("hookTargets gagal: " + t);
        }
        return any;
    }

    /** Menambahkan efek miring ke matriks yang dikirim launcher ke SurfaceControl. */
    private boolean hookSetMatrix(ClassLoader cl) {
        try {
            Class<?> props = XposedHelpers.findClassIfExists(CLS_PROPS, cl);
            if (props == null) {
                log("class tidak ditemukan: " + CLS_PROPS);
                return false;
            }
            XposedHelpers.findAndHookMethod(props, "setMatrix", Matrix.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            try {
                                Matrix src = (Matrix) p.args[0];
                                if (src == null) return;
                                long now = SystemClock.uptimeMillis();
                                boolean opening = true;

                                if (TiltConfig.FILTER_APP_LEASH_ONLY) {
                                    Object surface =
                                            XposedHelpers.getObjectField(p.thisObject, "mSurface");
                                    long[] e = surface == null ? null : sLeashes.get(surface);
                                    if (e == null || now > e[1]) return;
                                    opening = e[0] == 1L;
                                } else if (now > sAnyActiveUntil) {
                                    return;
                                }

                                if (opening && !TiltConfig.APPLY_ON_OPEN) return;
                                if (!opening && !TiltConfig.APPLY_ON_CLOSE) return;

                                Matrix out = TiltMath.tilt(src, opening);
                                if (out != null) {
                                    p.args[0] = out;
                                    if (TiltConfig.DEBUG_LOG && sDebugFrames++ < 5) {
                                        log("tilt diterapkan, opening=" + opening);
                                    }
                                }
                            } catch (Throwable t) {
                                // Jangan pernah membuat launcher crash karena efek.
                                if (TiltConfig.DEBUG_LOG && sDebugFrames++ < 5) {
                                    log("setMatrix error: " + t);
                                }
                            }
                        }
                    });
            return true;
        } catch (Throwable t) {
            log("hookSetMatrix gagal: " + t);
            return false;
        }
    }

    private static void record(Object targets, boolean opening) {
        try {
            if (!(targets instanceof Object[])) return;
            long until = SystemClock.uptimeMillis() + TiltConfig.MAX_ACTIVE_MS;
            sAnyActiveUntil = until;
            for (Object t : (Object[]) targets) {
                if (t == null) continue;
                Object leash = XposedHelpers.getObjectField(t, "leash");
                if (leash != null) {
                    sLeashes.put(leash, new long[]{opening ? 1L : 0L, until});
                }
            }
            if (TiltConfig.DEBUG_LOG) {
                log((opening ? "buka" : "tutup") + ": " + ((Object[]) targets).length + " target");
            }
        } catch (Throwable t) {
            log("record gagal: " + t);
        }
    }

    private static void log(String msg) {
        XposedBridge.log(TAG + msg);
    }
}
