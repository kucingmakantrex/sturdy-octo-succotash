# HiOS Tilt Animation (LSPosed)

Menambahkan efek miring pada animasi buka/tutup aplikasi dari ikon di HiOS Launcher
(`com.transsion.hilauncher`). Animasi bawaan tidak diganti, hanya ditambah efek miring.

## Build
**Android Studio:** Open folder ini, tunggu sync, lalu Build > Build APK(s).
**Dari HP (GitHub):** upload folder ini ke repo GitHub, tab Actions > Build APK > Run workflow,
lalu unduh artifact `HiOSTilt-debug`.

Kalau Gradle gagal mengunduh `de.robv.android.xposed:api:82`, unduh `api-82.jar`,
taruh di `app/libs/`, lalu ganti baris dependency menjadi:
`compileOnly files('libs/api-82.jar')`

## Pasang
1. Install APK, buka LSPosed > Modul > aktifkan **HiOS Tilt Animation**.
2. Scope: centang **HiOS Launcher** saja.
3. Matikan paksa HiOS Launcher (atau reboot), lalu coba buka/tutup aplikasi.

## Atur efek
Semua nilai ada di `app/src/main/java/com/hios/tilt/TiltConfig.java`
(`ROLL_DEG`, `SKEW_X`, `PITCH_SQUASH`, `SIDE_SIGN`, dst). Ubah, build ulang, pasang lagi.

## Kalau tidak ada efek
Lihat log LSPosed, cari `[HiOSTilt]`, lalu buka dan tutup satu aplikasi dari ikon.
- `hook runner=true, props.setMatrix=true, tx.setMatrix=true` harus muncul saat launcher start.
- `runner.onUpdate: targets=1, gesture=false` harus muncul saat animasi.
- `tilt diterapkan, opening=true/false` berarti efek sudah dipakai.
- Ada `onUpdate` tapi tidak ada `tilt diterapkan`: kemungkinan hook ter-inline ART. Jalankan
  `su -c "cmd package compile --reset com.transsion.hilauncher"`, lalu reboot dan coba lagi.
- `class tidak ditemukan`: versi launcher berbeda, hook perlu disesuaikan.

## Matikan darurat
Kalau launcher bermasalah: nonaktifkan modul di LSPosed lalu matikan paksa launcher.
Modul tidak menyentuh system_server, jadi tidak berisiko bootloop.
