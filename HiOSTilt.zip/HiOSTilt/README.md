# HiOS Tilt Animation (LSPosed)

Menambahkan efek miring pada animasi buka/tutup aplikasi dari ikon di HiOS Launcher
(`com.transsion.hilauncher`). Animasi bawaan tidak diganti, hanya ditambah efek miring.

## Build
**Android Studio:** Open folder ini, tunggu sync, lalu Build > Build APK(s).
**Dari HP (GitHub):** upload folder ini ke repo GitHub, tab Actions > Build APK > Run workflow,
lalu unduh artifact `HiOSTilt-debug`.

Kalau Gradle gagal mengunduh `de.robv.android.xposed:api:82`, unduh `api-82.jar`,
taruh di `app/libs/`, lalu ganti baris dependency menjadi:
`compileOnly files('libs/api-82.jar')`

## Pasang
1. Install APK, buka LSPosed > Modul > aktifkan **HiOS Tilt Animation**.
2. Scope: centang **HiOS Launcher** saja.
3. Matikan paksa HiOS Launcher (atau reboot), lalu coba buka/tutup aplikasi.

## Atur efek
Semua nilai ada di `app/src/main/java/com/hios/tilt/TiltConfig.java`
(`ROLL_DEG`, `SKEW_X`, `PITCH_SQUASH`, `SIDE_SIGN`, dst). Ubah, build ulang, pasang lagi.

## Kalau tidak ada efek
- Lihat log LSPosed, cari `[HiOSTilt]`. Harus ada baris `hook targets=true, setMatrix=true`
  dan `buka: ...`/`tutup: ...` setiap animasi.
- Kalau `buka/tutup` muncul tapi tidak ada `tilt diterapkan`, set `FILTER_APP_LEASH_ONLY = false`.
- Kalau ada `class tidak ditemukan`, versi launcher berbeda dari yang dianalisis dan hook perlu disesuaikan.

## Matikan darurat
Kalau launcher bermasalah: nonaktifkan modul di LSPosed lalu matikan paksa launcher.
Modul tidak menyentuh system_server, jadi tidak berisiko bootloop.
